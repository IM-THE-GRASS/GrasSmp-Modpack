# Fire_Rekindled
A 16x Minecraft resource pack with PBR support which overhauls most animated textures and adds a few new ones
